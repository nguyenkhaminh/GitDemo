package com.example.crudspringdatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSpringDataJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
