package com.example.crudspringdatajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudSpringDataJpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(CrudSpringDataJpaApplication.class, args);
    }

}
