package com.example.crudspringdatajpa.repository;

import com.example.crudspringdatajpa.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Integer> {
}
